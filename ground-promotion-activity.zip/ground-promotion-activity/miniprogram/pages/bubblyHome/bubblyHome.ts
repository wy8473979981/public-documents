// pages/bubblyHome/bubblyHome.ts
import { postRequest, getRequest } from '../../utils/request.js';
import { showToast } from '../../utils/index';
interface Bubble {
  x: number;
  y: number;
  radius: number;
  speed: number;
  drift: number;
  img: number;
}

Page({
  data: {
    loading: true,
    first: true,
    bubbles: [] as Bubble[],
    bubbleImg1: 'https://nav-uat.aia.com.cn/fan/sail/resource/bubblyActivity/images/bubbly-1.png',
    bubbleImg2: 'https://nav-uat.aia.com.cn/fan/sail/resource/bubblyActivity/images/bubbly-2.png',
    infinite: 'https://nav-uat.aia.com.cn/fan/sail/resource/hrActivity/images/infinite.gif',
  },
  touchTimer: 0,
  drawBubblesTimer: 0,
  createBubbleTimer: 0,
  pollingTimer: 0,

  /**
   * 生命周期函数--监听页面加载
  */
  onLoad() {
    this.getOpenId().then((res) => {
      console.log('getOpenId', res);
      if (res?.openId) {
        this.getList();
        this.pollingTimer = setInterval(this.getList, 4000);
      }
    })
  },
  onReady() { },
  onUnload() {
    clearTimeout(this.touchTimer);
    clearTimeout(this.drawBubblesTimer);
    clearInterval(this.createBubbleTimer);
    clearInterval(this.pollingTimer);
  },
  async getOpenId(expireDays = 2) {
    try {
      const loginCache = wx.getStorageSync('loginCache');
      const now = Date.now();
      const expireTime = expireDays * 24 * 60 * 60 * 1000;

      if (loginCache && loginCache.openId && loginCache.savedAt && now - loginCache.savedAt < expireTime) {
        console.log(`[cache] 使用已有缓存(loginCache)`);
        return loginCache; // 返回缓存数据
      }

      // 用 Promise 封装 wx.login
      const loginRes: any = await new Promise((resolve, reject) => {
        wx.login({
          success: resolve,
          fail: reject,
        });
      });

      if (!loginRes.code) {
        console.error('登录失败！', loginRes.errMsg);
        return null;
      }

      // 发起后端请求
      const result = await getRequest('/wx/user/login', {
        data: {
          code: loginRes.code,
        },
      });

      const { code, data } = result;

      if (code === '200') {
        const newCache = {
          openId: data?.openId || '',
          ntCode: data?.ntCode || '',
          savedAt: now,
        };

        await new Promise((resolve) => {
          wx.setStorage({
            key: 'loginCache',
            data: newCache,
            success: resolve,
            fail: resolve, // 即使失败也继续
          });
        });
        console.log(`[cache] 缓存更新成功(loginCache)`);
        return newCache; // 返回新数据
      } else {
        console.error('获取 openId 接口失败', result);
        return null;
      }
    } catch (error) {
      console.error('getOpenId error', error);
      return null;
    }
  },
  async pollingInterface() {
    const loginCache = wx.getStorageSync('loginCache');
    const params1 = {
      data: {
        openId: loginCache.openId,
        type: 1, // 1：有没有摇  4：有没有点击cheers
      },
    };
    const params2 = {
      data: {
        openId: loginCache.openId,
        type: 4, // 1：有没有摇  4：有没有点击cheers
      },
    };

    const [result1, result2] = await Promise.all([
      postRequest('/activity/get', params1),
      postRequest('/activity/get', params2)
    ]);

    if (result1.data) {
      if (result1.data?.status === 1) {
        let status = result2.data?.status;
        wx.redirectTo({
          url: `/pages/cheersPage/cheersPage?status=${status}`
        });
      } else {
        const recordId = result1.data.id;
        wx.redirectTo({ url: `/pages/shakePage/shakePage?recordId=${recordId}` });
      }
    } else {
      wx.redirectTo({ url: '/pages/shakePage/shakePage' });
    }
  },
  async getList() {
    try {
      const params = {
        data: {}
      }
      const result = await getRequest('/activity/getStart', params);
      const { code, msg, data } = result;
      if (code === "200") {
        if (data === "1") {
          // 开始了
          clearTimeout(this.touchTimer);
          clearTimeout(this.drawBubblesTimer);
          clearInterval(this.createBubbleTimer);
          clearInterval(this.pollingTimer);
          this.pollingInterface();
        } else {
          this.initCanvas(this.data.first);
          this.setData({ loading: false });
        }
      } else {
        showToast(msg);
      }
    } catch (error) {
      console.error('Polling error:', error);
    }
  },
  initCanvas(first: boolean) {
    if (first) {
      this.setData({ first: false });
      const query = wx.createSelectorQuery();
      query
        .select('#beerCanvas')
        .fields({ node: true, size: true })
        .exec((res) => {
          if (!res[0] || !res[0].node) return;

          const { bubbleImg1, bubbleImg2 } = this.data;
          const canvas = res[0].node;
          const ctx = canvas.getContext('2d');

          canvas.width = res[0]?.width;
          canvas.height = res[0]?.height;

          const bubbleImage1 = canvas.createImage();
          const bubbleImage2 = canvas.createImage();
          bubbleImage1.src = bubbleImg1;
          bubbleImage2.src = bubbleImg2;

          const createBubble = () => {
            const { bubbles } = this.data;
            const newBubble: Bubble = {
              x: Math.random() * (canvas.width - 20),
              y: canvas.height,
              radius: 20 + Math.random() * 15,
              speed: 1.6 + Math.random() * 1.4,
              drift: Math.random() * 2 - 1,
              img: 1,
            };
            this.setData({
              bubbles: [...bubbles, newBubble],
            });
          };

          const drawBubbles = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            const { bubbles } = this.data;

            bubbles.forEach((bubble) => {
              bubble.y -= bubble.speed;
              bubble.x += Math.sin(bubble.y * 0.03) * bubble.drift;
              bubble.x = Math.max(
                0,
                Math.min(canvas.width - bubble.radius, bubble.x)
              );
            });

            const newBubbles = bubbles.filter(
              (bubble) => bubble.y + bubble.radius > 0
            );
            this.setData({ bubbles: newBubbles });

            newBubbles.forEach((bubble) => {
              const bubbleImage = bubble.img === 1 ? bubbleImage1 : bubbleImage2;
              ctx.drawImage(
                bubbleImage,
                bubble.x,
                bubble.y,
                bubble.radius,
                bubble.radius
              );
            });

            if (bubbles.length <= 0) {
              clearTimeout(this.drawBubblesTimer);
            }

            this.drawBubblesTimer = setTimeout(drawBubbles, 16);
          };

          bubbleImage1.onload = () => {
            this.createBubbleTimer = setInterval(() => createBubble(), 300);
            drawBubbles();
          };
        });
    }
  },
  onClickCanvas(event: any) {
    const { pageX, pageY } = event.touches[0];
    // 先生成一个泡泡
    this.createBubble(pageX, pageY);
  },
  /** 处理触摸开始 */
  onTouchStart(event: any) {
    const { pageX, pageY } = event.touches[0];

    // 先生成一个泡泡
    this.createBubble(pageX, pageY);

    // 启动定时器，持续生成气泡
    this.touchTimer = setInterval(() => {
      this.createBubble(pageX, pageY);
    }, 200); // 每 100ms 生成一个气泡
  },

  /** 处理触摸结束 */
  onTouchEnd() {
    if (this.touchTimer) {
      clearInterval(this.touchTimer);
    }
  },

  /** 创建气泡 */
  createBubble(x: number, y: number) {
    const { bubbles } = this.data;
    const newBubble: Bubble = {
      x,
      y,
      radius: 40 + Math.random() * 10,
      speed: 1.6 + Math.random() * 1.4,
      drift: Math.random() * 2 - 1,
      img: 2, // 随机使用两种泡泡图片
    };

    this.setData({
      bubbles: [...bubbles, newBubble],
    });
  },
});
